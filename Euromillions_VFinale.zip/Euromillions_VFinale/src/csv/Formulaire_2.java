package csv;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.Random;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;

import javax.imageio.ImageIO;
import javax.swing.*;

public class Formulaire_2 extends JFrame implements ActionListener{
	
	private String put_boule_1 = null;
	private String put_boule_2 = null;
	private String put_boule_3 = null;
	private String put_boule_4 = null;
	private String put_boule_5 = null;
	private String put_etoile_1 = null;
	private String put_etoile_2 = null;

	
	private JTextField field_put_boule_1 = new JTextField("", 8); 
	private JTextField field_put_boule_2 = new JTextField("", 8); 
	private JTextField field_put_boule_3 = new JTextField("", 8); 
	private JTextField field_put_boule_4 = new JTextField("", 8); 
	private JTextField field_put_boule_5 = new JTextField("", 8); 
	private JTextField field_put_etoile_1 = new JTextField("", 8); 
	private JTextField field_put_etoile_2 = new JTextField("", 8); 
	
	private JTextField resultat = new JTextField("", 8); 
	
	private JTextField field_random_boule_1 = new JTextField("", 8); 
	private JTextField field_random_boule_2 = new JTextField("", 8); 
	private JTextField field_random_boule_3 = new JTextField("", 8); 
	private JTextField field_random_boule_4 = new JTextField("", 8); 
	private JTextField field_random_boule_5 = new JTextField("", 8); 
	private JTextField field_random_etoile_1 = new JTextField("", 8); 
	private JTextField field_random_etoile_2 = new JTextField("", 8); 
	
	private JButton b1 =  new JButton("Jouez!");
	//private JTextField t = new JTextField("Text field 3", 8); 
	 Font f = new Font("fontname", Font.PLAIN, 20);

//	 private App game = new App();
//	private int tab1[];
	
	 
	public Formulaire_2() {
		setVisible(true);
		setTitle("Gameplay");
		setSize(320 , 600);
		setResizable(false);
		setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		//setVisible(true);
		
		getContentPane().setLayout(null);
		
		
		//Champ dont les utilisateurs rentrent leurs valeurs pour jouer
	    field_put_boule_1.setBounds(60, 80,30, 30);
	    getContentPane().add(field_put_boule_1);
	    field_put_boule_2.setBounds(60, 120,30, 30);
	    getContentPane().add(field_put_boule_2);
	    field_put_boule_3.setBounds(60, 160,30, 30);
	    getContentPane().add(field_put_boule_3);
	    field_put_boule_4.setBounds(60, 200,30, 30);
	    getContentPane().add(field_put_boule_4);
	    field_put_boule_5.setBounds(60, 240,30, 30);
	    getContentPane().add(field_put_boule_5);
	    field_put_etoile_1.setBounds(60, 280,30, 30);
	    getContentPane().add(field_put_etoile_1);
	    field_put_etoile_2.setBounds(60, 320,30, 30);
	    getContentPane().add(field_put_etoile_2);
	    
	    //Champ dont l'ordinateur rentre la valeur
	    field_random_boule_1.setBounds(200, 80,30, 30);
	    getContentPane().add(field_random_boule_1);
	    field_random_boule_2.setBounds(200, 120,30, 30);
	    getContentPane().add(field_random_boule_2);
	    field_random_boule_3.setBounds(200, 160,30, 30);
	    getContentPane().add(field_random_boule_3);
	    field_random_boule_4.setBounds(200, 200,30, 30);
	    getContentPane().add(field_random_boule_4);
	    field_random_boule_5.setBounds(200, 240,30, 30);
	    getContentPane().add(field_random_boule_5);
	    field_random_etoile_1.setBounds(200, 280,30, 30);
	    getContentPane().add(field_random_etoile_1);
	    field_random_etoile_2.setBounds(200, 320,30, 30);
	    getContentPane().add(field_random_etoile_2);
	    
	    
		b1.setBounds(93, 380, 100, 60);
		b1.addActionListener(this);
		getContentPane().add(b1);
		
		resultat.setBounds(7, 450, 300, 30);
		getContentPane().add(resultat);
		
		
		
		JLabel label_instructions = new JLabel("Test");
		label_instructions.setText("Misez des valeurs pour tenter votre chance!");
		label_instructions.setForeground(Color.ORANGE);
		label_instructions.setFont(new Font("Times New Roman", Font.PLAIN | Font.BOLD, 16));
		label_instructions.setBounds(5, 0,300, 20);
		getContentPane().add(label_instructions);
		
		JLabel label_instructions_2 = new JLabel("Test");
		label_instructions_2.setText("Valeur des boules: 1 � 20  |  Valeur des �toiles: 1 � 12");
		label_instructions_2.setForeground(Color.BLUE);
		label_instructions_2.setBounds(5, 30,300, 20);
		getContentPane().add(label_instructions_2);
		
		
		JLabel label_user = new JLabel("Test");
		label_user.setText("Utilisateur");
		label_user.setBounds(50, 50,60, 30);
		getContentPane().add(label_user);
		JLabel label_machine= new JLabel("Test");
		label_machine.setText("Machine");
		label_machine.setBounds(190, 50,60, 30);
		getContentPane().add(label_machine);
		JLabel label_message= new JLabel("Test");
		label_message.setText("Message");
		label_message.setBounds(120, 475,60, 30);
		getContentPane().add(label_message);
		
		JLabel label_b1 = new JLabel("Test");
		label_b1.setText("boule 1");
		label_b1.setBounds(10, 80,60, 30);
		getContentPane().add(label_b1);
		JLabel label_b2 = new JLabel("Test");
		label_b2.setText("boule 2");
		label_b2.setBounds(10, 120,60, 30);
		getContentPane().add(label_b2);
		JLabel label_b3 = new JLabel("Test");
		label_b3.setText("boule 3");
		label_b3.setBounds(10, 160,60, 30);
		getContentPane().add(label_b3);
		JLabel label_b4 = new JLabel("Test");
		label_b4.setText("boule 4");
		label_b4.setBounds(10, 200,60, 30);
		getContentPane().add(label_b4);
		JLabel label_b5 = new JLabel("Test");
		label_b5.setText("boule 5");
		label_b5.setBounds(10, 240,60, 30);
		getContentPane().add(label_b5);
		JLabel label_e1 = new JLabel("Test");
		label_e1.setText("�toile 1");
		label_e1.setBounds(10, 280,60, 30);
		getContentPane().add(label_e1);
		JLabel label_e2 = new JLabel("Test");
		label_e2.setText("�toile 2");
		label_e2.setBounds(10, 320,60, 30);
		getContentPane().add(label_e2);
	
		
	}
	
	 public void actionPerformed(ActionEvent e) {
		 
		 int tab_user[] = new int[7];
		 //Prendre les numeros mises par l'utilisateur
		 put_boule_1 = field_put_boule_1.getText();
		 put_boule_2 = field_put_boule_2.getText();
		 put_boule_3 = field_put_boule_3.getText();
		 put_boule_4 = field_put_boule_4.getText();
		 put_boule_5 = field_put_boule_5.getText();
		 put_etoile_1 = field_put_etoile_1.getText();
		 put_etoile_2 = field_put_etoile_2.getText();
		 
		 //convertir le string en integer pour verifier les valeurs mises par l'utilisateur
		 tab_user[0] = Integer.parseInt(put_boule_1);
		 tab_user[1] = Integer.parseInt(put_boule_2);
		 tab_user[2] = Integer.parseInt(put_boule_3);
		 tab_user[3] = Integer.parseInt(put_boule_4);
		 tab_user[4] = Integer.parseInt(put_boule_5);
		 tab_user[5] = Integer.parseInt(put_etoile_1);
		 tab_user[6] = Integer.parseInt(put_etoile_2);
		 
		 //Tableau qui recupere les valeurs randoms donn�s par l'ordinateur
		 int tab_machine[] = new int[7];
		 App game = new App();
		 tab_machine=game.tirage_du_jour();
		 
		
		 
		 //Champ qui prend les valeurs randoms donn�s par le tableau de retour
		 field_random_boule_1.setText(String.valueOf(tab_machine[0]));
		 field_random_boule_2.setText(String.valueOf(tab_machine[1]));
		 field_random_boule_3.setText(String.valueOf(tab_machine[2]));
		 field_random_boule_4.setText(String.valueOf(tab_machine[3]));
		 field_random_boule_5.setText(String.valueOf(tab_machine[4]));
		 field_random_etoile_1.setText(String.valueOf(tab_machine[5]));
		 field_random_etoile_2.setText(String.valueOf(tab_machine[6]));
		 
		 
		 
		 String message;
		 
		 if(game.verification_entree(tab_user, tab_machine)==true) {
			 message="ERROR: mettez des valeurs valides";
			 resultat.setText(message);
		 }else {
			//Verifier si l'utilisateur a gagn� quelque chose !
			 int valeur = game.argent_gagne(tab_user, tab_machine);
			 if(valeur >0) {
				 new BallsImage_2(tab_machine, String.valueOf(valeur));
				 resultat.setText("Bravo! Vous avez gagn� "+String.valueOf(valeur)+"�");
			 }else {
				 resultat.setText("YOU LOSE!");
			 }
		 //message=String.valueOf(game.argent_gagne(tab_user, tab_machine));
		///	 message=String.valueOf(valeur);
		 }
		 
		 
		 
		// resultat.setText(message+"�");
		  } 
	
}

