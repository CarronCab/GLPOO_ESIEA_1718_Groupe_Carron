package csv;
import java.util.Random;

public class App {
	
	//Atributs (variables)
	

	int tab_tirage_du_jour[] = new int [7];
	public App (){
	
	}
	
	  
	  // Fonction qui envoit un tableau du tirage random par la machine
	  public int[] tirage_du_jour()  {
	  		
		  Random rand = new Random();
	    	int a=0;
	    	int b=0;
	    	int c=0;
	    	int d=0;
	    	int e=0;
	    	int f=0;
	    	int g=0;

	    	/*a =rand.nextInt((20-1+1)+1);
	    	b =rand.nextInt((20-1+1)+1);
	    	c =rand.nextInt((20-1+1)+1);
	    	d =rand.nextInt((20-1+1)+1);
	    	e =rand.nextInt((20-1+1)+1);
	    	f =rand.nextInt((12-1+1)+1);
	    	g =rand.nextInt((12-1+1)+1);*/
	    	
	    	a =rand.nextInt(20);if(a==0) {a=1;}
	    	b =rand.nextInt(20);if(b==0) {b=1;}
	    	c =rand.nextInt(20);if(c==0) {c=1;}
	    	d =rand.nextInt(20);if(d==0) {d=1;}
	    	e =rand.nextInt(20);if(e==0) {e=1;}
	    	f =rand.nextInt(12);if(f==0) {f=1;}
	    	g =rand.nextInt(12);if(g==0) {g=1;}
	      //  System.out.println(a+" "+b+" "+c+" "+d+" "+e+" "+f+" "+g);

	       // System.out.println("Voici le tirage:"+" "+a+" "+b+" "+c+" "+d+" "+e+" "+f+" "+g);
	        tab_tirage_du_jour[0]=a;
	        tab_tirage_du_jour[1]=b;
	        tab_tirage_du_jour[2]=c;
	        tab_tirage_du_jour[3]=d;
	        tab_tirage_du_jour[4]=e;
	        tab_tirage_du_jour[5]=f;
	        tab_tirage_du_jour[6]=g;
	        
	        return tab_tirage_du_jour;
	    }
	  
	  //Fonction qui verifie la vraisamblance entre le tableau des valeurs mises par l'utilsateur et 
	  //les valeurs mises par la machine
	  public int argent_gagne(int numbers_user[], int numbers_machine[]) {
		  int money=0; //Stocke la quantit� d'argent gagn� par l'utilisateur (100� de plus pour les boules, 300 de plus pour les �toiles)
		  
		  //Verifier si les boules mises par l'utilisateur sont �gales � celles mises par la machine
		  for(int i=0;i<5;i++) {
			  if(numbers_user[i] == numbers_machine[i]) {
				  money=money+100;
			  }
			  
		  }
		  //Verifier si les �toiles mises par l'utilisateur sont �gales � celles mises par la machine
		  if(numbers_user[5] == numbers_machine[5]) { money=money+300;}
		  if(numbers_user[6] == numbers_machine[6]) { money=money+300;}
			  
		  return money;
	  }
	  
	  
	  //Fonction qui re�oit 2 tableau et verifie si l'utilisateur a rentr� les bons valeurs 
	  //Tester si la verification se fait bien.
	  public boolean verification_entree(int numbers_user[], int numbers_machine[]) {
		  
		 int verification=0;
		  //Verifier si les boules mises par l'utilisateur sont accept�s pour le jeu ou pas
		  for(int i=0;i<5;i++) {
			  if(numbers_user[i]>=21 || numbers_user[i]<=0 ) {
				 verification = 1;
			  }
		  }
		  //Verifier si les etoiles mises par l'utilisateur sont acceptes pour le jeu ou pas
		  if(numbers_user[5]>=12 || numbers_user[5]<=0 ) {verification = 1;}
		  if(numbers_user[6]>=12 || numbers_user[6]<=0 ) {verification = 1;}
		  
		  if(verification ==1) { return true;}
		  else {return false;}
	  }
}
