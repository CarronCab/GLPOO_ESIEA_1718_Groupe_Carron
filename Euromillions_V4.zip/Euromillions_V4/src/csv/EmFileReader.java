package csv;

import java.awt.Font;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.plaf.basic.BasicLabelUI;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

public class EmFileReader implements ActionListener {

	private BufferedReader br;
	private JPanel contentPane;
	public JTextField num_tirage;
	public JTextField date_tirage;
	public JTextField boule_1;
	public JTextField etoile_1;
	public JTextField boule_2;
	public JTextField boule_3;
	public JTextField boule_4;
	public JTextField boule_5;
	public JTextField etoile_2;
	public JTextField boule_gagnante;
	public JTable table;
	public int[] resultTable = null; 
		
	
	String filePath ="euromillions_4.csv";
	public void actionPerformed(ActionEvent e) {	
		
		JFrame frame = new JFrame("This is your CSV file content");
		frame.setVisible(true);
	//	JFrame.setDefaultLookAndFeelDecorated(true);
		frame.setExtendedState(Frame.MAXIMIZED_BOTH);
		frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		JPanel panel = new JPanel();
		frame.add(panel);
		JTable table = new JTable();
		panel.add(table);
		
		// JSCROLLPANE
				JScrollPane scrollpane = new JScrollPane();
				scrollpane.setViewportView(panel);
				frame.add(scrollpane);
		
	File file = new File(filePath);
	try {
		
		br = new BufferedReader(new FileReader(file));
		String firstLine = br.readLine().toString().trim();
		String[] colName = firstLine.split(";");
		DefaultTableModel model = (DefaultTableModel)table.getModel(); 
		model.setColumnIdentifiers(colName);
		model.addRow(colName);
		
		// GET LINE FROME FILE
        Object[] tableLines = br.lines().toArray();
        
        // REMPLISSAGE DU TABLEAU
        for(int i = 0; i < tableLines.length; i++)
        {
            String line = tableLines[i].toString().trim();
            String[] dataRow = line.split(";");
            model.addRow(dataRow);
        }
        
	} catch (Exception e1) {
		Logger.getLogger(EmFileReader.class.getName()).log(Level.SEVERE, null, e1);
	}
	
	// SELECTION DE LA LIGNE
	
	ListSelectionModel showRow = table.getSelectionModel();
	
	showRow.addListSelectionListener(new ListSelectionListener(){
		
		public void valueChanged(ListSelectionEvent e) {
			JFrame frame1 = new JFrame("Voici vos r�sultats");
			
			//
			
			frame1.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
			frame1.setBounds(100, 100, 450, 300);
			
			contentPane = new JPanel();
			frame1.add(contentPane);
			contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
			frame1.setContentPane(contentPane);
			contentPane.setLayout(null);
			
			JPanel panel = new JPanel();
			panel.setBounds(5, 5, 424, 1);
			contentPane.add(panel);
			panel.setLayout(null);
			frame1.add(panel);
			
			JLabel lblNumtirage = new JLabel("Num tirage:");
			lblNumtirage.setFont(new Font("Arial Black", Font.PLAIN, 15));
			lblNumtirage.setBounds(80, 19, 104, 32);
			contentPane.add(lblNumtirage);
			
			JLabel lblDate = new JLabel("Date:");
			lblDate.setFont(new Font("Arial Black", Font.PLAIN, 15));
			lblDate.setBounds(134, 62, 50, 32);
			contentPane.add(lblDate);
			
			JLabel lblnumeroDeJeu = new JLabel(" Num\u00E9ros des boules:");
			lblnumeroDeJeu.setFont(new Font("Arial Black", Font.PLAIN, 15));
			lblnumeroDeJeu.setBounds(3, 105, 181, 32);
			contentPane.add(lblnumeroDeJeu);
			
			num_tirage = new JTextField();
			num_tirage.setBounds(211, 25, 130, 24);
			contentPane.add(num_tirage);
			num_tirage.setColumns(10);
			
			date_tirage = new JTextField();
			date_tirage.setColumns(10);
			date_tirage.setBounds(211, 68, 130, 24);
			contentPane.add(date_tirage);
			
			boule_1 = new JTextField();
			boule_1.setColumns(10);
			boule_1.setBounds(211, 111, 32, 24);
			contentPane.add(boule_1);
			
			JLabel lblBouleGagnante = new JLabel(" Boule Gagnante:");
			lblBouleGagnante.setFont(new Font("Arial Black", Font.PLAIN, 15));
			lblBouleGagnante.setBounds(35, 189, 156, 32);
			contentPane.add(lblBouleGagnante);
			
			etoile_1 = new JTextField();
			etoile_1.setColumns(10);
			etoile_1.setBounds(211, 154, 32, 24);
			contentPane.add(etoile_1);
			
			boule_2 = new JTextField();
			boule_2.setColumns(10);
			boule_2.setBounds(250, 111, 32, 24);
			contentPane.add(boule_2);
			
			boule_3 = new JTextField();
			boule_3.setColumns(10);
			boule_3.setBounds(291, 111, 32, 24);
			contentPane.add(boule_3);
			
			boule_4 = new JTextField();
			boule_4.setColumns(10);
			boule_4.setBounds(333, 111, 32, 24);
			contentPane.add(boule_4);
			
			boule_5 = new JTextField();
			boule_5.setColumns(10);
			boule_5.setBounds(374, 111, 32, 24);
			contentPane.add(boule_5);
			
			JLabel lblEtoileGagnante = new JLabel("Etoile gagnante:");
			lblEtoileGagnante.setFont(new Font("Arial Black", Font.PLAIN, 15));
			lblEtoileGagnante.setBounds(39, 148, 145, 32);
			contentPane.add(lblEtoileGagnante);
			
			etoile_2 = new JTextField();
			etoile_2.setColumns(10);
			etoile_2.setBounds(253, 154, 32, 24);
			contentPane.add(etoile_2);
			
			boule_gagnante = new JTextField();
			boule_gagnante.setColumns(10);
			boule_gagnante.setBounds(211, 195, 145, 24);
			contentPane.add(boule_gagnante);
			
			// AFFICHAGE DE CERTAINES INFOS DE LA LISTE DANS DES ZONES DE TEXTE
			
			int index = table.getSelectedRow();
			DefaultTableModel model = (DefaultTableModel)table.getModel();
			
			// REPERAGE DES COLONNES
			String numTirage = model.getValueAt(index, 0).toString();
			String date = model.getValueAt(index, 4).toString();
			String boule1  = model.getValueAt(index, 5).toString();
			String boule2  = model.getValueAt(index, 6).toString();
			String boule3 = model.getValueAt(index, 7).toString();
			String boule4 = model.getValueAt(index, 8).toString();
			String boule5 = model.getValueAt(index, 9).toString();
			String etoile1 = model.getValueAt(index, 10).toString();
			String etoile2 = model.getValueAt(index, 11).toString();
			String bouleGagnante = model.getValueAt(index, 12).toString();
			
			//AFFICHAGE DANS ZONES DE TEXT
			num_tirage.setText(numTirage);
			date_tirage.setText(date);
			boule_1.setText(boule1);
			boule_2.setText(boule2);
			boule_3.setText(boule3);
			boule_4.setText(boule4);
			boule_5.setText(boule5);
			etoile_1.setText(etoile1);
			etoile_2.setText(etoile2);
			boule_gagnante.setText(bouleGagnante);
			
			// STOCKAGE DES RESULTATS DANS UN TABLEAU
			String ArrayRow[]= {boule1,boule2,boule3,boule4,boule5, etoile1, etoile2};
					
			//elias:ajouter un tableau qui contient la date et le numero du tirage en STRING
			String TextToShow[]= {date,numTirage};

			
			// CONVERSION D'UN STRING A UN ENTIER
			resultTable = new int[ArrayRow.length];
			for (int i=0; i<resultTable.length; i++) {
				resultTable[i] = Integer.parseInt(ArrayRow[i]);
				//System.out.println(resultTable[i]);
			}

				new BallsImage(resultTable,TextToShow);

		}	
		
	});
	}
	public int[] getResultTable() {
		return resultTable;
	}
}

	

