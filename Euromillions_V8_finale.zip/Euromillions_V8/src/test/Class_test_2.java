package test;

import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.util.Random;

import csv.App;
import csv.EmFileReader;
import csv.Interface_test;

public class Class_test_2 extends App  implements Interface_test {

	@Override
	public int[] tirage_du_jour() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int argent_gagne(int[] numbers_user, int[] numbers_machine) {
		// TODO Auto-generated method stub
		return 0;
	}

	

	@Override
	public int[] getResultTable() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		
		
	}

}
