package csv;

import java.awt.event.ActionEvent;
public interface Interface_test {

	int[] tirage_du_jour();
	int argent_gagne(int numbers_user[], int numbers_machine[]);
	boolean verification_entree(int numbers_user[], int numbers_machine[]);
	int[] getResultTable();
	void actionPerformed(ActionEvent e);
}
