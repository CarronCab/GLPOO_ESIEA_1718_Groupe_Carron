package csv;


import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.Font;

import javax.swing.JTextPane;


public class FrameFile extends JFrame {

	private JPanel contentPane;
	private JTextPane txtWelcomeToEuromillion;
	
	public FrameFile() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 0, 0);

		contentPane.add(panel);
		panel.setLayout(null);
		
		
		txtWelcomeToEuromillion = new JTextPane();
		txtWelcomeToEuromillion.setBounds(28, 5, 401, 60);
		txtWelcomeToEuromillion.setToolTipText("");
		txtWelcomeToEuromillion.setForeground(new Color(255, 0, 0));
		txtWelcomeToEuromillion.setFont(new Font("Times New Roman", Font.ITALIC, 36));
		txtWelcomeToEuromillion.setBackground(Color.ORANGE);
		txtWelcomeToEuromillion.setText("Welcome to Euromillion");
		contentPane.add(txtWelcomeToEuromillion);
		
		JButton btnCliquerIciPour = new JButton("Cliquez ici pour voir l'historique des r\u00E9sultas");
		contentPane.add(btnCliquerIciPour);
		btnCliquerIciPour.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 16));
		btnCliquerIciPour.setBounds(44, 96, 349, 60);
		btnCliquerIciPour.addActionListener(new EmFileReader());
		
	}
	
}
