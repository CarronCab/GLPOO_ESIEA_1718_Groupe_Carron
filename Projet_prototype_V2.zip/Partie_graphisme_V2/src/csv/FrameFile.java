package csv;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextField;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;

import javax.swing.SwingConstants;
import javax.swing.JTextArea;
import javax.swing.JTextPane;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.awt.event.ActionEvent;

public class FrameFile extends JFrame {

	private JPanel contentPane;
	private JTextPane txtWelcomeToEuromillion;
	private BufferedImage image;
	
	public FrameFile() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		//setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 0, 0);
	/*	ImageIcon pic = new ImageIcon("Images/euromillions_2.gif");
		panel.add(new JLabel(pic));*/
		
	/*	ImageIcon icon = new ImageIcon(this.getClass().getResource("/app/images/background.png"));
		Dimension dimension = new Dimension(icon.getImage().getWidth(null),icon.getImage().getHeight(null));
        this.setPreferredSize(dimension);
        this.setMaximumSize(dimension);
        this.setMaximumSize(dimension);
        this.setSize(dimension);
        this.setLayout(null);
		*/
		contentPane.add(panel);
		panel.setLayout(null);
		
		
		    /*   try {                
		          image = ImageIO.read(new File("Images/euromillions_2.gif"));
		         // image =  ImageIO.read(this.getClass().getResource("Images/euromillions_2.gif"));
		       } catch (IOException ex) {
		           System.out.println("Lol");
		       }
		  
		       JLabel picLabel = new JLabel(new ImageIcon(image));
		       add(picLabel);*/
		
		
		txtWelcomeToEuromillion = new JTextPane();
		txtWelcomeToEuromillion.setBounds(28, 5, 401, 60);
		txtWelcomeToEuromillion.setToolTipText("");
		txtWelcomeToEuromillion.setForeground(new Color(255, 0, 0));
		txtWelcomeToEuromillion.setFont(new Font("Times New Roman", Font.ITALIC, 36));
		txtWelcomeToEuromillion.setBackground(Color.ORANGE);
		txtWelcomeToEuromillion.setText("Welcome to Euromillion");
		contentPane.add(txtWelcomeToEuromillion);
		
		JButton btnCliquerIciPour = new JButton("Cliquez ici pour voir l'historique des r\u00E9sultas");
		contentPane.add(btnCliquerIciPour);
		btnCliquerIciPour.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 16));
		btnCliquerIciPour.setBounds(44, 96, 349, 60);
		btnCliquerIciPour.addActionListener(new EmFileReader());
		
	}
	/*	protected void paintComponent(Graphics g) {
        super.paintComponents(g);
        g.drawImage(image, 0, 0, null); // see javadoc for more info on the parameters            
    }*/
	
}
