package test;

import java.awt.Graphics;
import java.util.Random;
import csv.EmFileReader;
import csv.Interface_test;

public class Class_test extends EmFileReader  implements Interface_test {

	@Override
	public int[] tirage_du_jour() {
		int tab_tirage_du_jour[] = new int [7];
		Random rand = new Random();
    	int a=0;
    	int b=0;
    	int c=0;
    	int d=0;
    	int e=0;
    	int f=0;
    	int g=0;

    	a =rand.nextInt((20-1+1)+1);
    	b =rand.nextInt((20-1+1)+1);
    	c =rand.nextInt((20-1+1)+1);
    	d =rand.nextInt((20-1+1)+1);
    	e =rand.nextInt((20-1+1)+1);
    	f =rand.nextInt((12-1+1)+1);
    	g =rand.nextInt((12-1+1)+1);
    	
    	 tab_tirage_du_jour[0]=a;
	        tab_tirage_du_jour[1]=b;
	        tab_tirage_du_jour[2]=c;
	        tab_tirage_du_jour[3]=d;
	        tab_tirage_du_jour[4]=e;
	        tab_tirage_du_jour[5]=f;
	        tab_tirage_du_jour[6]=g;
	        
	        return tab_tirage_du_jour;
		
	}
	
	@Override
	public int argent_gagne(int numbers_user[], int numbers_machine[]) {
		int money=0;
		for(int i=0;i<5;i++) {
			  if(numbers_user[i] == numbers_machine[i]) {
				  money=money+100;
			  }
		 }
		  //Verifier si les �toiles mises par l'utilisateur sont �gales � celles mises par la machine
		  if(numbers_user[5] == numbers_machine[5]) { money=money+300;}
		  if(numbers_user[6] == numbers_machine[6]) { money=money+300;}
			  
		  return money;
		
		
	}

	

	@Override
	public int[] getResultTable() {
		
		return resultTable;
	}

	@Override
	public boolean verification_entree(int[] numbers_user, int[] numbers_machine) {
		int verification=0;
		  //Verifier si les boules mises par l'utilisateur sont accept�s pour le jeu ou pas
		  for(int i=0;i<5;i++) {
			  if(numbers_user[i]>=21 || numbers_user[i]<=0 ) {
				 verification = 1;
			  }
		  }
		  //Verifier si les etoiles mises par l'utilisateur sont acceptes pour le jeu ou pas
		  if(numbers_user[5]>=12 || numbers_user[5]<=0 ) {verification = 1;}
		  if(numbers_user[6]>=12 || numbers_user[6]<=0 ) {verification = 1;}
		  
		  if(verification ==1) { return true;}
		  else {return false;}
	}

	
	
	
	
}
