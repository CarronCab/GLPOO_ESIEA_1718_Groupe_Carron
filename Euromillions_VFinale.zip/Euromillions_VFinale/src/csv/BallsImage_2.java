package csv;

/////////////////////
import javax.swing.*;
//////////////////////////////////

import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;

public class BallsImage_2 extends JFrame {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	Image image;
	Image image2;
	Image image3;


	int Number[]=null;
	int Possition_X_Numbers[]={80,170,360,720,990};
	int Possition_Y_Numbers[]= {450,350,250,350,450};
	int taille_Y[]= {100,200,300,200,100};
	int taille_X[]= {175,350,525,350,175};
	Image imagen;
	String TextToShow;
	
	// Constructeur
	public BallsImage_2(int Numeros[], String TextToShow) {


		this.setTitle("Gain du joueur");
		this.setSize(1280, 720);
		this.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);

		this.setVisible(true);
		this.setLocation(0, 0);

		this.Number = Numeros;
		this.TextToShow=TextToShow;
		
		/***********************************
		 * Sauvegarder l'image de la fen�tre qui affiche le tirage s�lectionn� 
		 ********************************/
		
		try {
			BufferedImage image = new BufferedImage(getWidth(), getHeight(), BufferedImage.TYPE_INT_RGB);
			Graphics2D graphics2D = image.createGraphics();
			this.paint(graphics2D);
		//	TextToShow[0] = TextToShow[0].replaceAll("/","-");
			ImageIO.write(image, "jpeg", new File("save_images_game/"+String.valueOf(Numeros[0])+"_" 
			+String.valueOf(Numeros[1])+"_"+ String.valueOf(Numeros[2])+"_"+
					String.valueOf(Numeros[3])+"_"+String.valueOf(Numeros[4])+"_"
					+String.valueOf(Numeros[5])+"_"+String.valueOf(Numeros[6])
					+"_euromillions.jpeg"));
			//System.out.println("L'image a �t� sauvegard�e");
		} catch (Exception exception) {
		
		}

		/*******************************
		 * Fin du sauvegarde de l'image
		 ********************************/
	}
	
	
	/*******************************
	 * M�thode que affiche la representation graphique du tirage s�lectionn� (boules). 
	 ********************************/
	public void peindre(Graphics g, int Pos_X, int taille_y,int taille_x, int hauteur ,int numero) {
	
			if(numero<4) {
				ImageIcon i = new ImageIcon("images/jaune.gif");
				 image = i.getImage();
				 g.drawImage(image, Pos_X, hauteur,taille_x,taille_y, null);
			}else 
			{
				if(numero<8) {
					ImageIcon i = new ImageIcon("images/vert.gif");
					 image = i.getImage();
					 g.drawImage(image, Pos_X, hauteur,taille_x,taille_y, null);
				}else {
					if(numero<12)
					{
						ImageIcon i = new ImageIcon("images/rouge.gif");
						 image = i.getImage();
						 g.drawImage(image, Pos_X, hauteur,taille_x,taille_y, null);
					}else {
						if(numero<16) {
							ImageIcon i = new ImageIcon("images/bleu.gif");
							 image = i.getImage();
							 g.drawImage(image, Pos_X, hauteur,taille_x,taille_y, null);
						}else {
							if(numero<=20)
							{
								ImageIcon i = new ImageIcon("images/magenta.gif");
								 image = i.getImage();
								 g.drawImage(image, Pos_X, hauteur,taille_x,taille_y, null);
							}
						}
					}
				}
			}
		
			g.setColor(Color.BLACK);
			g.setFont(new Font("Arial", Font.BOLD, taille_y/2));
			if(numero>=10) {
			g.drawString(String.valueOf(numero), Pos_X + taille_x/3 , hauteur + (int)(taille_y-taille_y/3));}
			else {
				g.drawString(String.valueOf(numero), Pos_X + (int)(taille_x/2.5) , hauteur + (int)(taille_y-taille_y/3));
			}
				
		}
	
	/*******************************
	 * M�thode que affiche la representation graphique du tirage s�lectionn� (�toiles). 
	 ********************************/
	public void etoile(Graphics g, int n1, int n2) {
	
		ImageIcon i = new ImageIcon("images/star.png");

		 image = i.getImage();
		 g.drawImage(image, 25, 100,300,300, null);
		 g.setColor(new java.awt.Color(255, 128, 0));
		 g.setFont(new Font("Arial", Font.BOLD, 200));
		 
		 if(n1>=10) {
				g.drawString(String.valueOf(n1), 60 , 330);}
				else {
					g.drawString(String.valueOf(n1), 120 , 330);
				}

		 g.drawImage(image, 880, 100,300,300, null);
		 g.setFont(new Font("Arial", Font.BOLD, 200));
		 if(n2>=10) {
				g.drawString(String.valueOf(n2), 910 , 330);}
				else {
					g.drawString(String.valueOf(n2), 970 , 330);
				}

	}
	
	
	public void paint(Graphics g) {
		
		//Appliquer la couleur grise au fond de la fen�tre (couleur par d�faut) 
		Color pardefault = new java.awt.Color(235, 235, 235); 
		g.setColor(pardefault); 
		g.fillRect(0, 0, 1280, 720); 
	
		//Montre une image de fond
		 ImageIcon image_background = new ImageIcon("images/las vegas.jpg");

		 image = image_background.getImage();
		 
		 g.drawImage(image, 0, 0,1280,720, null);
		 
		 //Affichage des feux d'artifices 
		 ImageIcon i4 = new ImageIcon("images/stars2.png");
		 Image image4 = i4.getImage();
		 g.drawImage(image4, 100, 150, null);
		 g.drawImage(image4, 000, 150, null);
		 g.drawImage(image4, 000, 250, null);
		 g.drawImage(image4, 000, 350, null);
		 g.drawImage(image4, 000, 450, null);
		 g.drawImage(image4, 100, 200, null);
		 g.drawImage(image4, 100, 300, null);
		 g.drawImage(image4, 100, 400, null);
		 g.drawImage(image4, 200, 400, null);
		 g.drawImage(image4, 300, 400, null);
		 g.drawImage(image4, 400, 300, null);
		 g.drawImage(image4, 600, 100, null);
		 g.drawImage(image4, 800, 300, null);
		 g.drawImage(image4, 200, 400, null);
		 g.drawImage(image4, 1000, 500, null);
		 g.drawImage(image4, 200, 400, null);
		 g.drawImage(image4, 000, 300, null);
		 
		 ImageIcon i5 = new ImageIcon("images/stars6.png");
		 Image image5 = i5.getImage();
		 g.drawImage(image5, 000, 0, null);
		 g.drawImage(image5, 300, 0, null);
		 g.drawImage(image5, 600, 0, null);
		 g.drawImage(image5, 900, 0, null);
		 g.drawImage(image5, 1200, 0, null);
		 
		 ImageIcon i6 = new ImageIcon("images/feu_artifices1.png");
		 Image image6 = i6.getImage();
		 g.drawImage(image6, 1000, 400, null);
		 g.drawImage(image6, 000, 400, null);
		 g.drawImage(image6, 1000, 0, null);
		 g.drawImage(image6, 00, 00, null);
		 
		 //Afficher les numeros gagnats dans des boules sur la fen�tre
		for (int i =0; i <5 ; i++)  //Number.length
		{
		if(Number[i] >= 1 && Number[i] <4)
		{
			peindre(g,Possition_X_Numbers[i],taille_Y[i],taille_X[i],Possition_Y_Numbers[i],Number[i]);
		}
		
		if(Number[i] >= 4 && Number[i] <8)
		{
			peindre(g,Possition_X_Numbers[i],taille_Y[i],taille_X[i],Possition_Y_Numbers[i],Number[i]);
		}
		if(Number[i] >= 8 && Number[i] <12)
		{
			peindre(g,Possition_X_Numbers[i],taille_Y[i],taille_X[i],Possition_Y_Numbers[i],Number[i]);
		}
		if(Number[i] >= 12 && Number[i] <15)
		{
			peindre(g,Possition_X_Numbers[i],taille_Y[i],taille_X[i],Possition_Y_Numbers[i],Number[i]);
		}
		if(Number[i] >= 15 && Number[i] <=20)
		{
			peindre(g, Possition_X_Numbers[i],taille_Y[i],taille_X[i],Possition_Y_Numbers[i],Number[i]);
		}
		}
		
		
		//Affichage des �toiles gagants dans la fen�tre
		
		etoile(g,Number[5],Number[6]);
		g.setFont(new Font("Arial", Font.BOLD, 80));	 
		
		//Affichage du titre EUROMILLIONS
		Graphics2D g2 = (Graphics2D) g;
		ImageIcon i2 = new ImageIcon("images/euromillions_2.gif");
		 image2 = i2.getImage();
		 g2.drawImage(image2, 450, 30,350,200, null);
		 
		 //Affichage des monnais
		 ImageIcon i3 = new ImageIcon("images/money3.gif");
		 image3 = i3.getImage();
		 g2.drawImage(image3, 0, 100, null);
		 
		 GradientPaint dessin_degrade =  new GradientPaint(50,50 , Color.GRAY , 100 , 50, Color.CYAN,true); //sans true si 
			g2.setPaint(dessin_degrade);
			g2.drawString(TextToShow+"�", 10, 700);
				


	}

}
