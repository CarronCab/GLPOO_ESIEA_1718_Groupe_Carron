package csv;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.sun.prism.Image;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextField;
import java.awt.Color;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JTextArea;
import javax.swing.JTextPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class FrameFile extends JFrame {

	private JPanel contentPane;

	public FrameFile() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 565, 371);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 0, 0);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JButton btnCliquerIciPour = new JButton("Cliquer ici pour voir l'historique des r\u00E9sultats");
		btnCliquerIciPour.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 16));
		btnCliquerIciPour.setBounds(86, 0, 377, 60);
		btnCliquerIciPour.addActionListener(new EmFileReader());
		contentPane.add(btnCliquerIciPour);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("euroImage.jpg"));
		lblNewLabel.setBounds(0, 0, 549, 332);
		contentPane.add(lblNewLabel);
	}
}
