package csv;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import java.awt.Font;

public class FrameFile extends JFrame {

	private JPanel contentPane;

	public FrameFile() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 565, 371);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 0, 0);
		contentPane.add(panel);
		panel.setLayout(null);
		
		//Bouton du haut
		JButton btnCliquerIciPour = new JButton("Cliquer ici pour voir l'historique des r\u00E9sultats");
		btnCliquerIciPour.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 16));
		btnCliquerIciPour.setBounds(86, 0, 377, 60);
		btnCliquerIciPour.addActionListener(new EmFileReader());
		contentPane.add(btnCliquerIciPour);
		
		//Bouton du bas
	/*	JButton btnPlay = new JButton("Cliquer ici pour jouer");
		btnPlay.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 16));
		btnPlay.setBounds(86, 200, 377, 60);
		btnPlay.addActionListener(new Formulaire_2());
		contentPane.add(btnPlay);*/
		Formulaire_2 form = new Formulaire_2();
	//	form.setVisible(true);
		
		//Image du fond
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("euroImage.jpg"));
		lblNewLabel.setBounds(0, 0, 549, 332);
		contentPane.add(lblNewLabel);
	}
}
