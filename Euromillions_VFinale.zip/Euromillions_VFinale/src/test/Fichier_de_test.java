package test;
import static org.junit.Assert.*; 

import org.junit.Before;
import org.junit.Test;

import csv.App;
import csv.Interface_test;

public class Fichier_de_test {
	App app;
	Interface_test calc;
	Interface_test tableau;
	Interface_test comfirmation;
	Interface_test comparaison;
	
@Before public void init() {
	app = new App();
	calc = new Class_test();
	tableau = new Class_test();
	comfirmation = new Class_test();
	comparaison = new Class_test();
}



@Test //Test la longueur du tableau alea
public void tirage_du_jourTest() {
	App app = new App();
	assertEquals(7, app.tirage_du_jour().length);
}

@Test // Test si le tableau est bien nulle avant remplissage
public void test_tirage_gagnant(){
	int valeur[] = null;
	int jackpot[] = comparaison.getResultTable();
	assertEquals(valeur,jackpot);
	
}

@Test // Test tout cas possible de gain
public void testArgent_gagn�(){
	int tab[] = {1,2,3,4,5,6,7};
	int tab2[] = tableau.tirage_du_jour();
	int money0 = 0;
	int money1 = 100;
	int money2 = 200;
	int money3 = 300;
	int money4 = 400;
	int money5 = 500;
	int money6 = 600;
	int money7 = 700;
	int money8 = 800;
	int money9 = 900;
	int money10 = 1000;
	int money11 = 1100;
	
	if(money0 == calc.argent_gagne(tab, tab2)) {
	assertEquals(money0, calc.argent_gagne(tab, tab2));
	}
	if(money1 == calc.argent_gagne(tab, tab2)) {
		assertEquals(money1, calc.argent_gagne(tab, tab2));
	}
	if(money2 == calc.argent_gagne(tab, tab2)) {
		assertEquals(money2, calc.argent_gagne(tab, tab2));
	}
	if(money2 == calc.argent_gagne(tab, tab2)) {
		assertEquals(money2, calc.argent_gagne(tab, tab2));
	}
	if(money3 == calc.argent_gagne(tab, tab2)) {
		assertEquals(money3, calc.argent_gagne(tab, tab2));
		}
	if(money4 == calc.argent_gagne(tab, tab2)) {
		assertEquals(money4, calc.argent_gagne(tab, tab2));
		}
	if(money5 == calc.argent_gagne(tab, tab2)) {
		assertEquals(money5, calc.argent_gagne(tab, tab2));
		}
	if(money6 == calc.argent_gagne(tab, tab2)) {
		assertEquals(money6, calc.argent_gagne(tab, tab2));
		}
		if(money7 == calc.argent_gagne(tab, tab2)) {
			assertEquals(money7, calc.argent_gagne(tab, tab2));
		}
		if(money8 == calc.argent_gagne(tab, tab2)) {
			assertEquals(money8, calc.argent_gagne(tab, tab2));
		}
		if(money9 == calc.argent_gagne(tab, tab2)) {
			assertEquals(money9, calc.argent_gagne(tab, tab2));
		}
		if(money10 == calc.argent_gagne(tab, tab2)) {
			assertEquals(money10, calc.argent_gagne(tab, tab2));
			}
		if(money11 == calc.argent_gagne(tab, tab2)) {
			assertEquals(money11, calc.argent_gagne(tab, tab2));
			}
		
	
		
}



@Test //Test les 5 premieres valeurs du tableau font +100 et les 2 dernieres +300 si les valeurs sont identiques
public void argent_gagneTest_arrayIdent_Test() {
	App app = new App();
	int numbers_alea[] = new int[] { 1, 2, 3, 4, 5, 6, 7 };
	int numbers_user[] = new int[] { 1, 2, 3, 4, 5, 6, 7 };

	assertEquals(1100, app.argent_gagne(numbers_user, numbers_alea));
}

@Test //Test les si la 6eme valeur des 2 tab sont identiques alors +300
public void argent_gagne_array5_Test() {
	App app = new App();
	int numbers_alea[] = new int[] { 4, 20, 3, 18, 9, 4, 13 };
	int numbers_user[] = new int[] { 5, 7, 17, 13, 16, 4, 12 };

	assertEquals(300, app.argent_gagne(numbers_user, numbers_alea));
}

@Test //Test les si la 7eme valeur des 2 tab sont identiques alors +300
public void argent_gagne_array6_Test() {
	App app = new App();
	int numbers_alea[] = new int[] { 4, 20, 3, 18, 1, 10, 11 };
	int numbers_user[] = new int[] { 5, 7, 17, 13, 5, 3, 11 };

	assertEquals(300, app.argent_gagne(numbers_user, numbers_alea));
	// assertArrayEquals(numbers_alea, numbers_user);
}

@Test // tester si les valeur <=21 ou valeur>=0 et que la 5eme et 6eme valeur >=12 ou >=0 return false
public void verificationfalse_entreeTest() {
	App app = new App();
	int numbers_alea[] = new int[] { 4, 20, 3, 18, 12, 7, 11 };
	int numbers_user[] = new int[] { 5, 7, 17, 13, 12, 8, 6 };

	assertEquals(false, app.verification_entree(numbers_alea, numbers_user));
}

@Test // tester si la 6eme valeur >=12 ou si elle est <=0 alors return true
public void verification5false_entreeTest() {
	App app = new App();
	int numbers_alea[] = new int[] { 4, 20, 3, 18, 12, -1, 11 };
	int numbers_user[] = new int[] { 5, 7, 17, 13, 12, -5, 6 };

	assertEquals(true, app.verification_entree(numbers_alea, numbers_user));
}

@Test // tester si la 7eme valeur >=12 ou si elle est <=0 alors return true
public void verification6false_entreeTest() {
	App app = new App();
	int numbers_alea[] = new int[] { 4, 20, 3, 18, 12, 7, -11 };
	int numbers_user[] = new int[] { 5, 7, 17, 13, 12, 8, -5 };

	assertEquals(true, app.verification_entree(numbers_alea, numbers_user));
}

@Test //Test s'il existe une valeur >=21 alors return true
public void verificationtrue_entreeTest() {
	App app = new App();
	int numbers_alea[] = new int[] { 4, 25, 3, 18, 12, 12, 15 };
	int numbers_user[] = new int[] { 5, 29, 17, 13, 12, 12, 15 };

	assertEquals(true, app.verification_entree(numbers_alea, numbers_user));
}

}
